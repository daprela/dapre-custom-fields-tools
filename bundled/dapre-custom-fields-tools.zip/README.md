This plugin is a 'swiss army knife' of custom fields. It allows you to manipulate them to make it easy the testing and debugging of applications

This plugin was built in a moment of desperation when I couldn't access phpMyAdmin in a mu website.
I absolutely needed to manipulate the custom fields for testing and debugging, version 1.0 was up in 4 hours.
In the following months I realized how useful the plugin was and couldn't work anymore without it. It had become part of my standard toolset.

Features:
1. It allows to read/write/delete options, user fields and post fields
2. It keeps track of the previous value that you gave to the field
3. You can toggle between date string values and time stamp values representations for date fields
4. You can rename a field
5. You can copy a field to a different field of the same type or to a field of a different type (example: copy an option to a user field)